package com.jarvis.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout home;
    private EditText urlInput;
    private PermissionRequest pendingRequest;
    private static final int PERM_REQ = 42;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,9,13));
        getWindow().setNavigationBarColor(Color.rgb(5,9,13));
        showHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    private void showHome() {
        home = new LinearLayout(this); home.setOrientation(LinearLayout.VERTICAL); home.setPadding(dp(22),dp(40),dp(22),dp(20)); home.setBackgroundColor(Color.rgb(5,9,13));
        TextView logo = text("J.A.R.V.I.S", 30, Color.rgb(0,229,255)); logo.setGravity(17); home.addView(logo);
        TextView sub = text("MOBILE INTERFACE  /  CONNECT", 12, Color.LTGRAY); sub.setGravity(17); home.addView(sub);
        TextView help = text("Bilgisayarındaki JARVIS uygulamasında TELEFON bağlantısını başlat. Ekranda çıkan HTTPS adresini buraya yapıştır. Bu uygulama tek başına bilgisayar ajanının yerine geçmez.", 15, Color.WHITE); help.setPadding(0,dp(28),0,dp(18)); home.addView(help);
        urlInput = new EditText(this); urlInput.setSingleLine(true); urlInput.setTextColor(Color.WHITE); urlInput.setHintTextColor(Color.GRAY); urlInput.setHint("https://... (JARVIS bağlantı adresi)"); urlInput.setText(getPreferences(0).getString("url", "")); urlInput.setSelectAllOnFocus(false); home.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(56)));
        Button connect = new Button(this); connect.setText("JARVIS'E BAĞLAN"); home.addView(connect, new LinearLayout.LayoutParams(-1, dp(56)));
        connect.setOnClickListener(v -> {
            String u = urlInput.getText().toString().trim();
            if (!(u.startsWith("https://") || u.startsWith("http://"))) { Toast.makeText(this,"JARVIS adresini https:// ile gir.",Toast.LENGTH_LONG).show(); return; }
            getPreferences(0).edit().putString("url",u).apply();
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(urlInput.getWindowToken(),0);
            showWeb(u);
        });
        setContentView(home);
    }
    private void showWeb(String url) {
        web = new WebView(this); web.setBackgroundColor(Color.rgb(5,9,13));
        web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setMediaPlaybackRequiresUserGesture(false); web.getSettings().setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl(); String scheme = u.getScheme();
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) return false;
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                boolean mic = false, cam = false;
                for (String r : request.getResources()) { if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) mic = true; if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true; }
                if ((!mic || checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) && (!cam || checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)) request.grant(request.getResources());
                else { pendingRequest = request; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA}, PERM_REQ); }
            }
        });
        setContentView(web); web.loadUrl(url);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode==PERM_REQ && pendingRequest!=null) {
            boolean ok = true; for (int r : grantResults) if (r!=PackageManager.PERMISSION_GRANTED) ok=false;
            if (ok) pendingRequest.grant(pendingRequest.getResources()); else pendingRequest.deny(); pendingRequest=null;
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else { web=null; showHome(); }
    }
}
