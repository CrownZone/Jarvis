JARVIS Mobile - Android proje kaynağı

Bu ZIP doğrudan APK değildir. Bilgisayarın yoksa GitHub Actions ile telefondan APK derlemeyi deneyebilirsin.

TELEFONDAN APK OLUŞTURMA (GitHub hesabı gerekir):
1. ZIP'i telefona indir ve dosya yöneticisiyle çıkar.
2. github.com üzerinden yeni bir repository oluştur. Örn. JARVIS-Android. Public veya Private seçebilirsin.
3. Çıkardığın JARVIS-Android klasörünün İÇİNDEKİ dosyaları repository'ye yükle. .github klasörünün de yüklendiğinden emin ol. GitHub web arayüzünde çoklu dosya yükleme desteklenmezse bunu GitHub Codespaces veya GitHub Desktop olan bir bilgisayarla yapmak gerekebilir.
4. Repository'de Actions sekmesine gir. "Build JARVIS Android APK" iş akışını seçip Run workflow düğmesine bas.
5. İşlem yeşil tikle bittiğinde çalışmanın sayfasını aç, Artifacts bölümünden JARVIS-Mobile-debug-APK dosyasını indir.
6. İnen artifact ZIP'ini çıkar; içindeki app-debug.apk dosyasını açarak kur. Android, tarayıcıya/dosya yöneticisine uygulama yükleme izni isteyebilir.

Yerel derleme (bilgisayar varsa): Android Studio'da bu klasörü aç ve Build > Build APK(s) seç.

ÖNEMLİ SINIRLAMA:
Bu uygulama, Windows JARVIS projesinin Android'e tamamen taşınmış hali değildir. Bilgisayarda çalışan JARVIS sunucusuna bağlanmak için tasarlanmış temel bir Android istemcisidir. Bilgisayardaki özel Windows komutları Android'de kendiliğinden çalışmaz.

GÜVENLİK:
JARVIS sunucu adresini/token'ını gizli tut. Hassas komutları herkese açık internete açma. Debug APK test amaçlıdır ve Play Store imzalı sürüm değildir.
